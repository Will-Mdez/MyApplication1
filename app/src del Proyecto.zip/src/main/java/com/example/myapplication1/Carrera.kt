package com.example.myapplication1

data class Carrera (
    val idCarrera: Int,
    val nombreCarrera: String,
    val siglaCarrera: String,
    val codigoCarrera: String,
    val idInstituto: Int
)