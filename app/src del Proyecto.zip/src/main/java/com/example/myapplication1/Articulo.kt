package com.example.myapplication1

data class Articulo(
    val idarticulo: Int,
    val tipoCRL: String,
    val tipoNI: String,
    val titulo: String,
    val fechaedicion: String,
    val autores: List<autores>
)