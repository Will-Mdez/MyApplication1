package com.example.myapplication1

data class actividades (
    val idActividad:Int,
    val idProfesor:Int,
    val actividad:String,
    val inicio:String,
    val fin:String,
    val descripcion:String,
    val validado:Int,
    val comprobante:String,
)