package com.example.myapplication1

data class eventos (
    val idProfesor: Int,
    val id: Int,
    val tipoEvento :String,
    val nombreEvento:String,
    val participacion:String,
    val afectaLinea:String,
    val tipoParticipacion:String,
    val titulo:String,
    val inicio:String,
    val fin: String,
    val comprobante:String
)