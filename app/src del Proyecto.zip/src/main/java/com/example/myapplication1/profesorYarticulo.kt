package com.example.myapplication1

data class profesorYarticulo (
    val idprofesor: Int,
    val idarticulo: Int,
    val pos: Int,
    val validado: Int
    )