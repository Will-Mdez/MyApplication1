package com.example.myapplication1

data class Institutos (
    val idInstitutos: Int,
    val nombreInstituto: String,
    val siglaInstituto: String,
    val codigoInstituto: String
)