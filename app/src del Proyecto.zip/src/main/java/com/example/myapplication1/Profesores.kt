package com.example.myapplication1

data class Profesores (
    val idProfesor: Int,
    val nombreProfesor: String,
    val apellidoPaterno: String,
    val apellidoMaterno: String,
    val grado: String,
    val idInstituto: Int,
    val idCarrera: Int,
    val rol: String
)
