package com.example.myapplication1

data class autores (
    val idProfesor:Int,
    val nombreProfesor:String,
    val apellidoPaterno:String,
    val apellidoMaterno:String,
    val idArticulo:Int,
    val pos:Int,
    val validado:Int
        )